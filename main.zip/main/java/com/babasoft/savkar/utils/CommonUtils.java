package com.babasoft.savkar.utils;

/**
 * Created by babaji on 14/9/16.
 */

public class CommonUtils {
public static String MAIN_URL="http://www.swapnpurticlasses.com/VoterSystem/api/";
}
